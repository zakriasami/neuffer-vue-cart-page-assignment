export interface CartTotals {
  subtotal: number
  tax: number
  shipping: number
  total: number
}