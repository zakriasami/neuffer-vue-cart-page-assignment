export interface ShippingInfo {
  country: string
  state: string
  zipCode: string
}