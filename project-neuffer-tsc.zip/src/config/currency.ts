export const appCurrencyConfig = {
  currency: 'EUR',
  locale: 'de-DE',
}
export const FRACTION_DIGITS = {
  MIN: 2,
  MAX: 2
}